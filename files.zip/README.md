# Student Dropout Prediction Agent

An n8n-based AI agent that reads student behavior data from Google Sheets, uses Groq (Llama 3.3 70B) to score dropout risk, and emails mentors about high-risk students every week.

## Problem

Edtech mentors often notice a student is dropping out only after it is too late. This agent monitors behavioral signals and flags at-risk students early, so mentors have time to step in.

## Workflow Screenshot

![n8n workflow canvas](workflow.png)

## How It Works

```
Schedule Trigger -> Google Sheets -> AI Agent (Groq) -> IF (HIGH risk?)
                                                          |-- true  -> Gmail alert to mentor
                                                          |-- false -> Append row to Google Sheets (log)
```

1. **Schedule Trigger** runs the workflow every Monday at 8 AM.
2. **Google Sheets** reads all student records.
3. **AI Agent** (Groq, `llama-3.3-70b-versatile`) analyzes each student and returns a JSON result with `risk_level`, `primary_reason` and `recommended_action`.
4. **IF node** checks whether the risk level is HIGH.
5. **Gmail** sends an alert email to the mentor for HIGH risk students.
6. **Google Sheets (Append row)** logs LOW and MEDIUM risk students.

## Input Signals

| Column | Description |
|---|---|
| student_id | Unique student ID |
| student_name | Student name |
| mentor_name | Assigned mentor |
| mentor_phone | Mentor contact number |
| sessions_attended / sessions_total | Session attendance |
| assignments_submitted / assignments_total | Assignment submission rate |
| whatsapp_response_hours | WhatsApp response latency |
| questions_asked | Question frequency |
| project_milestone_done | Project milestone status (Yes/No) |
| last_active_days_ago | Days since last activity |
| notes | Mentor notes |

## Sample AI Output

```json
{
  "risk_level": "HIGH",
  "primary_reason": "The student has not attended most sessions, submitted no assignments, and has been inactive for 9 days.",
  "recommended_action": "Mentor should immediately call the student to understand the reason for inactivity."
}
```

## Tech Stack

- n8n (workflow automation)
- Groq API with Llama 3.3 70B (AI analysis)
- Google Sheets API (data source and logging)
- Gmail API (mentor alerts)

## Setup

1. Install and run n8n locally (`npx n8n` or Docker).
2. Import `workflow.json` into n8n: create a new workflow, click `...`, then **Import from file**.
3. Create a Google Sheet named **Student Tracker** with the columns listed above and add your student data.
4. Add your own credentials in n8n:
   - **Google Sheets OAuth2** (Google Cloud Console, enable Google Sheets API and Drive API)
   - **Gmail OAuth2** (enable Gmail API)
   - **Groq API key** (free from console.groq.com)
5. Update the recipient email in the Gmail node.
6. Click **Execute workflow** to test, then **Publish** to activate the weekly schedule.

## Notes and Limitations

- The Groq free tier allows about 30 requests per minute. For large student lists, add a **Wait** node (2 to 3 seconds) before the AI Agent.
- Keep only one row per student in the sheet to avoid duplicate alerts.
- Do not commit API keys, client secrets or real student data to this repository.

## Future Improvements

- Send alerts through WhatsApp instead of email
- Store each student's risk history to track trends over time
- Add a dashboard for mentors
- Use a real LMS API instead of a Google Sheet

## Author

Diksha Lote
